# Run Tests
`sbt test`

# Build
`sbt assembly`

# Run it
`./bounding-box < world.txt`